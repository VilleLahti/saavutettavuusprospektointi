# Saavutettavuusprospektointi
Tämä Streamlit-sovellus hakee potentiaalisia verkkosivustoja saavutettavuusauditointia varten ja tallentaa ne Google Sheetiin.